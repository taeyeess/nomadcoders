const quotes = [
    {
        quote: "우리는 아직 자연이 우리에게 보여준 모습의 100,000분의 1도 모르고 있다.",
        author: "Albert Einstein"
    },
    {
        quote: "당신은 지체할 수도 있지만 시간은 그러하지 않을 것이다.",
        author: "벤자민 프랭클린"
    },
    {
        quote: "웃음의 절정은 우주를 새로운 가능성의 만화경속으로 내던진다.",
        author: "Jean Houston"
    },
    {
        quote: "마음으로 보아야만 분명하게 볼 수 있어. 정말 중요한 것은 눈에 보이지 않는 법이거든.",
        author: "Antoine de Saint-Exupery"
    },
    {
        quote: "코끼리의 뒷다리를 잡았는데 코끼리가 도망가려고 하면 그냥 도망가도록 놔두는 것이 가장 좋다.",
        author: "에이브러햄 링컨"
    },
    {
        quote: "완전한 진실만을 말하는 방법은 두 가지뿐이다. 익명으로 하거나, 유언으로 하거나.",
        author: "Thomas Sowell"
    },
    {
        quote: "미래는 현재 우리가 무엇을 하는가에 달려 있다.",
        author: "마하트마 간디"
    },
    {
        quote: "어떤 재능 혹은 다른 재능으로 뛰어난 사람이 될 수 있도록 노력하라.",
        author: "Seneca"
    },
    {   quote: "천재란 자신에게 주어진 일을 하는 재능 있는 사람일 뿐이다.",
        author: "Thomas A. Edison"
    },
    {
        quote: "스스로를 존경하면 다른 사람도 당신을 존경할 것이다.",
        author: "Confucius"
    }    
];

const quote = document.querySelector("#quote span:first-child");
const author = document.querySelector("#quote span:last-child");

const todaysQuote = quotes[Math.floor(Math.random() * quotes.length)];

quote.innerText = todaysQuote.quote;
author.innerText = todaysQuote.author;