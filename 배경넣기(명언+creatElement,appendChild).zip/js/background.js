const images = ["8k-mountain-lake-landscape-picture-wallpaper-preview.jpg", "590c15748cd8f5ef2ef791cc50294188.jpg", "Our-Earth_1920x1200.jpg"];

const chosenImage = images[Math.floor(Math.random() * images.length)];

const bgImage = document.createElement("img");

bgImage.src=`./img/${chosenImage}`;

document.body.appendChild(bgImage);